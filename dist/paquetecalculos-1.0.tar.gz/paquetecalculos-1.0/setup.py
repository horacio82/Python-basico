from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Horacio",
	author_email="molinarih2011@gmail.com",
	packages=["calculos","calculos.redondeo_potencia"]

	)