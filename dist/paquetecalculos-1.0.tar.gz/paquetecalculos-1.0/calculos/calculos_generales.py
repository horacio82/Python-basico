#Pildoras informaticas
#Paquetes - video 35

def sumar(op1,op2):
	print("El resultado de la suma es: ",op1+op2)

def restar(op1,op2):
	print("El resultado de la resta es: ",op1-op2)

def multiplicar(op1,op2):
	print("El resultado de la multiplicación es: ",op1*op2)

def dividir(dividendo,divisor):
	print("El resultado de la división es: ",dividendo/divisor)

def potencia(base,exponente):
	print("La potencia es:",base**exponente)

def redondear(numero):
	print("Redondeo:",round(numero))				