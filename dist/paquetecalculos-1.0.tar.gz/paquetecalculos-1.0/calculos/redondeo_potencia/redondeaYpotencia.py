#Pildoras informaticas
#Paquetes - video 35



def potencia(base,exponente):
	print("La potencia es:",base**exponente)

def redondear(numero):
	print("Redondeo:",round(numero))