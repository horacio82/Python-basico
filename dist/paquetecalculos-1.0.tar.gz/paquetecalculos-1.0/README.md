# Python
Píldoras informáticas-Curso básico de Python desde cero.
